# Internal Documentation for FirebaseUI-Android

This folder contains documentation needed to be a contributor or
owner of this project.

Contents:

  * [Branching Strategy](branching.md)
  * [Releasing](releasing.md)
  * [Translations](translations.md)
