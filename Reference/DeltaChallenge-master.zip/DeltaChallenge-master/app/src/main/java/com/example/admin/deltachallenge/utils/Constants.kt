package com.example.admin.deltachallenge.utils

object Constants {
    const val BASE_URL = "https://qrng.anu.edu.au/"
}