package com.yeah.ruisu.mvvmarchitecturecomponents.utils;

public class Constants
{
    public static class URLS
    {
        public static final String WEATHER_API_BASE_URL = "http://api.openweathermap.org/";
    }
}
