package com.yeah.ruisu.week3daily1;

import android.os.Bundle;
import android.app.Activity;

public class RandomList extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_list);
    }

}
