package com.firebase.ui.auth.data.model;

import android.support.annotation.RestrictTo;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public enum State {
    SUCCESS, FAILURE, LOADING
}
