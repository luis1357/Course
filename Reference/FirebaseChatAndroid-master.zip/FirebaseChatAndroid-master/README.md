# FirebaseChatAndroid

The complete guide showing how this sample was developed can be found at:
https://medium.com/@dekoservidoni/realtime-chats-with-firebase-in-android-a2a131f94e0c

### App Structure

![Firebase Structure](firebase_app_structure.png)
