package com.yeah.ruisu.mvvmarchitecturecomponents.di;

import com.yeah.ruisu.mvvmarchitecturecomponents.MainActivity;

import dagger.Component;

@Component(modules = MainModule.class)
public interface MainComponent
{
    void inject(MainActivity MyMainActivity);
}
