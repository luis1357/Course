dependencies {
    api(Config.Libs.Arch.runtime)
    api(Config.Libs.Arch.viewModel)
    implementation(Config.Libs.Support.annotations)
    annotationProcessor(Config.Libs.Arch.compiler)
}
