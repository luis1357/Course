package com.universetelecom.mvvm_users.utils;

/**
 * Created by Ahmad Shubita on 8/1/17.
 */

public interface Constant {

    public final  String BASE_URL = "http://api.randomuser.me/";
    public final  String RANDOM_USER_URL = "http://api.randomuser.me/?results=10&nat=en";
    public final  String PROJECT_URL = "https://github.com/AhmadShubita/MVVM-with-RXJava-and-Retrofit-Users-Generated-Example-";

}
