dependencies {
    api(Config.Libs.Misc.glide)

    api(Config.Libs.Firebase.storage)
    // Override Play Services
    implementation(Config.Libs.Support.v4)
}
