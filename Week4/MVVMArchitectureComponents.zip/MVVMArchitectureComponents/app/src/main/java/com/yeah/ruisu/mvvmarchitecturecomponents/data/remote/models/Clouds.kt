package com.yeah.ruisu.mvvmarchitecturecomponents.data.remote.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Clouds {

    @SerializedName("all")
    @Expose
    var all: Int? = null

}
