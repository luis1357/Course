dependencies {
    lintChecks(project(":internal:lint"))
}
